﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using PEPlugin;
using PEPlugin.Pmd;


namespace AutoLuminousSetter
{
    public class AutoLuminousSetter : IPEPlugin
    {

        Form1 frm;

        public void Run(IPERunArgs args)
        {
            
            if (Form1.shown == false)
            {
                frm = new Form1(args.Host);
                Form1.shown = true;
                frm.Show();
                
            }

        }

        public string Name
        {
            get { return "AutoLuminousSetter"; }
        }

        public string Description
        {
            get { return ""; }
        }

        public string Version
        {
            get
            {
                //自分自身のAssemblyを取得し、バージョンを返す
                System.Reflection.Assembly asm =
                    System.Reflection.Assembly.GetExecutingAssembly();
                System.Version ver = asm.GetName().Version;
                return ver.ToString();
            }
        }

        class option : IPEPluginOption
        {
            public bool Bootup { get { return false; } }  // 起動時実行
            public bool RegisterMenu { get { return true; } }  // プラグインメニューへの登録
            public string RegisterMenuText { get { return "AutoLuminousSetter"; } }
        }

        public IPEPluginOption Option
        {
            get { return new option(); }
        }

        public void Dispose()
        {
            ;
        }


    }
}
