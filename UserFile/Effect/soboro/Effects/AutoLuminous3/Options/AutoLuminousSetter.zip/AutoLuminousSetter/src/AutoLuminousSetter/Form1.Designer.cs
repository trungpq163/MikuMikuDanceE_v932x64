﻿namespace AutoLuminousSetter
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label5 = new System.Windows.Forms.Label();
            this.btnSetSelMat = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.listMaterial = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPower = new System.Windows.Forms.TextBox();
            this.lblPower = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.lblB = new System.Windows.Forms.Label();
            this.txtG = new System.Windows.Forms.TextBox();
            this.lblG = new System.Windows.Forms.Label();
            this.txtR = new System.Windows.Forms.TextBox();
            this.lblR = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBRect = new System.Windows.Forms.CheckBox();
            this.txtPhase = new System.Windows.Forms.TextBox();
            this.lblPhase = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.lblT = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtPopup = new System.Windows.Forms.TextBox();
            this.lblPopup = new System.Windows.Forms.Label();
            this.txtTexSub = new System.Windows.Forms.TextBox();
            this.lblTexSub = new System.Windows.Forms.Label();
            this.checkEnable = new System.Windows.Forms.CheckBox();
            this.listColorType = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.lblMName = new System.Windows.Forms.Label();
            this.checkMEnable = new System.Windows.Forms.CheckBox();
            this.txtMP = new System.Windows.Forms.TextBox();
            this.lblMP = new System.Windows.Forms.Label();
            this.txtMB = new System.Windows.Forms.TextBox();
            this.lblMB = new System.Windows.Forms.Label();
            this.txtMG = new System.Windows.Forms.TextBox();
            this.lblMG = new System.Windows.Forms.Label();
            this.txtMR = new System.Windows.Forms.TextBox();
            this.lblMR = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.現在の設定を保存ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.設定をファイルから開くToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.編集EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.設定コピーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.設定ペーストToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.全頂点に適用ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.画面上の設定をリセットToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.すべての設定を消去ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.すべての追加UVを消去ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.全ての材質で設定ログの再実行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ヘルプHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.変数一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.関数一覧ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSetMat = new System.Windows.Forms.Button();
            this.btnSetSelVtx = new System.Windows.Forms.Button();
            this.checkAutoLoadMaterialSetting = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkMOverride = new System.Windows.Forms.CheckBox();
            this.listTexMode = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQ = new System.Windows.Forms.TextBox();
            this.lblQ = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(497, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "材質:";
            // 
            // btnSetSelMat
            // 
            this.btnSetSelMat.Location = new System.Drawing.Point(501, 422);
            this.btnSetSelMat.Name = "btnSetSelMat";
            this.btnSetSelMat.Size = new System.Drawing.Size(183, 26);
            this.btnSetSelMat.TabIndex = 11;
            this.btnSetSelMat.Text = "選択材質で実行";
            this.btnSetSelMat.UseVisualStyleBackColor = true;
            this.btnSetSelMat.Click += new System.EventHandler(this.btnSetSelMat_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.Location = new System.Drawing.Point(12, 389);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(462, 30);
            this.lblMessage.TabIndex = 14;
            // 
            // listMaterial
            // 
            this.listMaterial.FormattingEnabled = true;
            this.listMaterial.ItemHeight = 12;
            this.listMaterial.Location = new System.Drawing.Point(499, 53);
            this.listMaterial.Name = "listMaterial";
            this.listMaterial.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listMaterial.Size = new System.Drawing.Size(183, 316);
            this.listMaterial.TabIndex = 15;
            this.listMaterial.SelectedIndexChanged += new System.EventHandler(this.listMaterial_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPower);
            this.groupBox1.Controls.Add(this.lblPower);
            this.groupBox1.Controls.Add(this.txtB);
            this.groupBox1.Controls.Add(this.lblB);
            this.groupBox1.Controls.Add(this.txtG);
            this.groupBox1.Controls.Add(this.lblG);
            this.groupBox1.Controls.Add(this.txtR);
            this.groupBox1.Controls.Add(this.lblR);
            this.groupBox1.Location = new System.Drawing.Point(12, 143);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(228, 132);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "発光色";
            // 
            // txtPower
            // 
            this.txtPower.Location = new System.Drawing.Point(62, 96);
            this.txtPower.Name = "txtPower";
            this.txtPower.Size = new System.Drawing.Size(149, 19);
            this.txtPower.TabIndex = 7;
            this.txtPower.Text = "0";
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Location = new System.Drawing.Point(18, 99);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(38, 12);
            this.lblPower.TabIndex = 6;
            this.lblPower.Tag = "txtPower";
            this.lblPower.Text = "Power:";
            this.lblPower.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(62, 71);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(149, 19);
            this.txtB.TabIndex = 5;
            this.txtB.Text = "0";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(18, 74);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(15, 12);
            this.lblB.TabIndex = 4;
            this.lblB.Tag = "txtB";
            this.lblB.Text = "B:";
            this.lblB.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtG
            // 
            this.txtG.Location = new System.Drawing.Point(62, 46);
            this.txtG.Name = "txtG";
            this.txtG.Size = new System.Drawing.Size(149, 19);
            this.txtG.TabIndex = 3;
            this.txtG.Text = "0";
            // 
            // lblG
            // 
            this.lblG.AutoSize = true;
            this.lblG.Location = new System.Drawing.Point(18, 49);
            this.lblG.Name = "lblG";
            this.lblG.Size = new System.Drawing.Size(15, 12);
            this.lblG.TabIndex = 2;
            this.lblG.Tag = "txtG";
            this.lblG.Text = "G:";
            this.lblG.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtR
            // 
            this.txtR.Location = new System.Drawing.Point(62, 21);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(149, 19);
            this.txtR.TabIndex = 1;
            this.txtR.Text = "0";
            // 
            // lblR
            // 
            this.lblR.AutoSize = true;
            this.lblR.Location = new System.Drawing.Point(18, 24);
            this.lblR.Name = "lblR";
            this.lblR.Size = new System.Drawing.Size(15, 12);
            this.lblR.TabIndex = 0;
            this.lblR.Tag = "txtR";
            this.lblR.Text = "R:";
            this.lblR.Click += new System.EventHandler(this.lbl_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBRect);
            this.groupBox2.Controls.Add(this.txtPhase);
            this.groupBox2.Controls.Add(this.lblPhase);
            this.groupBox2.Controls.Add(this.txtT);
            this.groupBox2.Controls.Add(this.lblT);
            this.groupBox2.Location = new System.Drawing.Point(12, 281);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(228, 98);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "点滅制御";
            // 
            // checkBRect
            // 
            this.checkBRect.AutoSize = true;
            this.checkBRect.Location = new System.Drawing.Point(20, 70);
            this.checkBRect.Name = "checkBRect";
            this.checkBRect.Size = new System.Drawing.Size(84, 16);
            this.checkBRect.TabIndex = 19;
            this.checkBRect.Text = "矩形波点滅";
            this.checkBRect.UseVisualStyleBackColor = true;
            // 
            // txtPhase
            // 
            this.txtPhase.Location = new System.Drawing.Point(62, 45);
            this.txtPhase.Name = "txtPhase";
            this.txtPhase.Size = new System.Drawing.Size(149, 19);
            this.txtPhase.TabIndex = 11;
            this.txtPhase.Text = "0";
            // 
            // lblPhase
            // 
            this.lblPhase.AutoSize = true;
            this.lblPhase.Location = new System.Drawing.Point(18, 48);
            this.lblPhase.Name = "lblPhase";
            this.lblPhase.Size = new System.Drawing.Size(31, 12);
            this.lblPhase.TabIndex = 10;
            this.lblPhase.Tag = "txtPhase";
            this.lblPhase.Text = "位相:";
            this.lblPhase.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(62, 20);
            this.txtT.Name = "txtT";
            this.txtT.Size = new System.Drawing.Size(149, 19);
            this.txtT.TabIndex = 9;
            this.txtT.Text = "0";
            // 
            // lblT
            // 
            this.lblT.AutoSize = true;
            this.lblT.Location = new System.Drawing.Point(18, 23);
            this.lblT.Name = "lblT";
            this.lblT.Size = new System.Drawing.Size(31, 12);
            this.lblT.TabIndex = 8;
            this.lblT.Tag = "txtT";
            this.lblT.Text = "周期:";
            this.lblT.Click += new System.EventHandler(this.lbl_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtQ);
            this.groupBox3.Controls.Add(this.lblQ);
            this.groupBox3.Controls.Add(this.listTexMode);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtPopup);
            this.groupBox3.Controls.Add(this.lblPopup);
            this.groupBox3.Controls.Add(this.txtTexSub);
            this.groupBox3.Controls.Add(this.lblTexSub);
            this.groupBox3.Controls.Add(this.checkEnable);
            this.groupBox3.Controls.Add(this.listColorType);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Location = new System.Drawing.Point(12, 38);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(462, 99);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "オプション";
            // 
            // txtPopup
            // 
            this.txtPopup.Location = new System.Drawing.Point(296, 43);
            this.txtPopup.Name = "txtPopup";
            this.txtPopup.Size = new System.Drawing.Size(149, 19);
            this.txtPopup.TabIndex = 22;
            this.txtPopup.Text = "0";
            // 
            // lblPopup
            // 
            this.lblPopup.AutoSize = true;
            this.lblPopup.Location = new System.Drawing.Point(216, 46);
            this.lblPopup.Name = "lblPopup";
            this.lblPopup.Size = new System.Drawing.Size(58, 12);
            this.lblPopup.TabIndex = 21;
            this.lblPopup.Tag = "txtPopup";
            this.lblPopup.Text = "ポップアップ:";
            this.lblPopup.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtTexSub
            // 
            this.txtTexSub.Location = new System.Drawing.Point(296, 18);
            this.txtTexSub.Name = "txtTexSub";
            this.txtTexSub.Size = new System.Drawing.Size(149, 19);
            this.txtTexSub.TabIndex = 20;
            this.txtTexSub.Text = "0";
            // 
            // lblTexSub
            // 
            this.lblTexSub.AutoSize = true;
            this.lblTexSub.Location = new System.Drawing.Point(216, 21);
            this.lblTexSub.Name = "lblTexSub";
            this.lblTexSub.Size = new System.Drawing.Size(74, 12);
            this.lblTexSub.TabIndex = 19;
            this.lblTexSub.Tag = "txtTexSub";
            this.lblTexSub.Text = "テクスチャ減算:";
            this.lblTexSub.Click += new System.EventHandler(this.lbl_Click);
            // 
            // checkEnable
            // 
            this.checkEnable.AutoSize = true;
            this.checkEnable.Checked = true;
            this.checkEnable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkEnable.Location = new System.Drawing.Point(20, 18);
            this.checkEnable.Name = "checkEnable";
            this.checkEnable.Size = new System.Drawing.Size(133, 16);
            this.checkEnable.TabIndex = 9;
            this.checkEnable.Text = "頂点発光を有効にする";
            this.checkEnable.UseVisualStyleBackColor = true;
            // 
            // listColorType
            // 
            this.listColorType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listColorType.FormattingEnabled = true;
            this.listColorType.Items.AddRange(new object[] {
            "RGB",
            "HSV"});
            this.listColorType.Location = new System.Drawing.Point(99, 40);
            this.listColorType.Name = "listColorType";
            this.listColorType.Size = new System.Drawing.Size(89, 20);
            this.listColorType.TabIndex = 8;
            this.listColorType.SelectedIndexChanged += new System.EventHandler(this.listColorType_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 12);
            this.label14.TabIndex = 7;
            this.label14.Text = "色指定:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.txtMName);
            this.groupBox5.Controls.Add(this.lblMName);
            this.groupBox5.Controls.Add(this.checkMEnable);
            this.groupBox5.Controls.Add(this.txtMP);
            this.groupBox5.Controls.Add(this.lblMP);
            this.groupBox5.Controls.Add(this.txtMB);
            this.groupBox5.Controls.Add(this.lblMB);
            this.groupBox5.Controls.Add(this.txtMG);
            this.groupBox5.Controls.Add(this.lblMG);
            this.groupBox5.Controls.Add(this.txtMR);
            this.groupBox5.Controls.Add(this.lblMR);
            this.groupBox5.Location = new System.Drawing.Point(246, 143);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(228, 202);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "モーフ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "※使用しない項目は空白に";
            // 
            // txtMName
            // 
            this.txtMName.Location = new System.Drawing.Point(62, 42);
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(149, 19);
            this.txtMName.TabIndex = 18;
            // 
            // lblMName
            // 
            this.lblMName.AutoSize = true;
            this.lblMName.Location = new System.Drawing.Point(18, 45);
            this.lblMName.Name = "lblMName";
            this.lblMName.Size = new System.Drawing.Size(31, 12);
            this.lblMName.TabIndex = 17;
            this.lblMName.Tag = "txtMName";
            this.lblMName.Text = "名前:";
            this.lblMName.Click += new System.EventHandler(this.lbl_Click);
            // 
            // checkMEnable
            // 
            this.checkMEnable.AutoSize = true;
            this.checkMEnable.Location = new System.Drawing.Point(20, 18);
            this.checkMEnable.Name = "checkMEnable";
            this.checkMEnable.Size = new System.Drawing.Size(103, 16);
            this.checkMEnable.TabIndex = 16;
            this.checkMEnable.Text = "モーフを作成する";
            this.checkMEnable.UseVisualStyleBackColor = true;
            this.checkMEnable.CheckedChanged += new System.EventHandler(this.checkMEnable_CheckedChanged);
            // 
            // txtMP
            // 
            this.txtMP.Location = new System.Drawing.Point(62, 142);
            this.txtMP.Name = "txtMP";
            this.txtMP.Size = new System.Drawing.Size(149, 19);
            this.txtMP.TabIndex = 7;
            // 
            // lblMP
            // 
            this.lblMP.AutoSize = true;
            this.lblMP.Location = new System.Drawing.Point(18, 145);
            this.lblMP.Name = "lblMP";
            this.lblMP.Size = new System.Drawing.Size(38, 12);
            this.lblMP.TabIndex = 6;
            this.lblMP.Tag = "txtMP";
            this.lblMP.Text = "Power:";
            this.lblMP.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtMB
            // 
            this.txtMB.Location = new System.Drawing.Point(62, 117);
            this.txtMB.Name = "txtMB";
            this.txtMB.Size = new System.Drawing.Size(149, 19);
            this.txtMB.TabIndex = 5;
            // 
            // lblMB
            // 
            this.lblMB.AutoSize = true;
            this.lblMB.Location = new System.Drawing.Point(18, 120);
            this.lblMB.Name = "lblMB";
            this.lblMB.Size = new System.Drawing.Size(15, 12);
            this.lblMB.TabIndex = 4;
            this.lblMB.Tag = "txtMB";
            this.lblMB.Text = "B:";
            this.lblMB.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtMG
            // 
            this.txtMG.Location = new System.Drawing.Point(62, 92);
            this.txtMG.Name = "txtMG";
            this.txtMG.Size = new System.Drawing.Size(149, 19);
            this.txtMG.TabIndex = 3;
            // 
            // lblMG
            // 
            this.lblMG.AutoSize = true;
            this.lblMG.Location = new System.Drawing.Point(18, 95);
            this.lblMG.Name = "lblMG";
            this.lblMG.Size = new System.Drawing.Size(15, 12);
            this.lblMG.TabIndex = 2;
            this.lblMG.Tag = "txtMG";
            this.lblMG.Text = "G:";
            this.lblMG.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txtMR
            // 
            this.txtMR.Location = new System.Drawing.Point(62, 67);
            this.txtMR.Name = "txtMR";
            this.txtMR.Size = new System.Drawing.Size(149, 19);
            this.txtMR.TabIndex = 1;
            // 
            // lblMR
            // 
            this.lblMR.AutoSize = true;
            this.lblMR.Location = new System.Drawing.Point(18, 70);
            this.lblMR.Name = "lblMR";
            this.lblMR.Size = new System.Drawing.Size(15, 12);
            this.lblMR.TabIndex = 0;
            this.lblMR.Tag = "txtMR";
            this.lblMR.Text = "R:";
            this.lblMR.Click += new System.EventHandler(this.lbl_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルFToolStripMenuItem,
            this.編集EToolStripMenuItem,
            this.ヘルプHToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(695, 26);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルFToolStripMenuItem
            // 
            this.ファイルFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.現在の設定を保存ToolStripMenuItem,
            this.設定をファイルから開くToolStripMenuItem});
            this.ファイルFToolStripMenuItem.Name = "ファイルFToolStripMenuItem";
            this.ファイルFToolStripMenuItem.Size = new System.Drawing.Size(85, 22);
            this.ファイルFToolStripMenuItem.Text = "ファイル(&F)";
            // 
            // 現在の設定を保存ToolStripMenuItem
            // 
            this.現在の設定を保存ToolStripMenuItem.Name = "現在の設定を保存ToolStripMenuItem";
            this.現在の設定を保存ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.現在の設定を保存ToolStripMenuItem.Text = "現在の設定をファイルに保存";
            this.現在の設定を保存ToolStripMenuItem.Click += new System.EventHandler(this.現在の設定を保存ToolStripMenuItem_Click);
            // 
            // 設定をファイルから開くToolStripMenuItem
            // 
            this.設定をファイルから開くToolStripMenuItem.Name = "設定をファイルから開くToolStripMenuItem";
            this.設定をファイルから開くToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.設定をファイルから開くToolStripMenuItem.Text = "設定をファイルから開く";
            this.設定をファイルから開くToolStripMenuItem.Click += new System.EventHandler(this.設定をファイルから開くToolStripMenuItem_Click);
            // 
            // 編集EToolStripMenuItem
            // 
            this.編集EToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.設定コピーToolStripMenuItem,
            this.設定ペーストToolStripMenuItem,
            this.toolStripMenuItem3,
            this.全頂点に適用ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.画面上の設定をリセットToolStripMenuItem,
            this.すべての設定を消去ToolStripMenuItem,
            this.すべての追加UVを消去ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.全ての材質で設定ログの再実行ToolStripMenuItem});
            this.編集EToolStripMenuItem.Name = "編集EToolStripMenuItem";
            this.編集EToolStripMenuItem.Size = new System.Drawing.Size(61, 22);
            this.編集EToolStripMenuItem.Text = "編集(&E)";
            // 
            // 設定コピーToolStripMenuItem
            // 
            this.設定コピーToolStripMenuItem.Name = "設定コピーToolStripMenuItem";
            this.設定コピーToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.設定コピーToolStripMenuItem.Text = "設定コピー";
            this.設定コピーToolStripMenuItem.Click += new System.EventHandler(this.設定コピーToolStripMenuItem_Click);
            // 
            // 設定ペーストToolStripMenuItem
            // 
            this.設定ペーストToolStripMenuItem.Name = "設定ペーストToolStripMenuItem";
            this.設定ペーストToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.設定ペーストToolStripMenuItem.Text = "設定ペースト";
            this.設定ペーストToolStripMenuItem.Click += new System.EventHandler(this.設定ペーストToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(253, 6);
            // 
            // 全頂点に適用ToolStripMenuItem
            // 
            this.全頂点に適用ToolStripMenuItem.Name = "全頂点に適用ToolStripMenuItem";
            this.全頂点に適用ToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.全頂点に適用ToolStripMenuItem.Text = "全頂点に適用";
            this.全頂点に適用ToolStripMenuItem.Click += new System.EventHandler(this.全頂点に適用ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(253, 6);
            // 
            // 画面上の設定をリセットToolStripMenuItem
            // 
            this.画面上の設定をリセットToolStripMenuItem.Name = "画面上の設定をリセットToolStripMenuItem";
            this.画面上の設定をリセットToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.画面上の設定をリセットToolStripMenuItem.Text = "画面上の設定をリセット";
            this.画面上の設定をリセットToolStripMenuItem.Click += new System.EventHandler(this.画面上の設定をリセットToolStripMenuItem_Click);
            // 
            // すべての設定を消去ToolStripMenuItem
            // 
            this.すべての設定を消去ToolStripMenuItem.Name = "すべての設定を消去ToolStripMenuItem";
            this.すべての設定を消去ToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.すべての設定を消去ToolStripMenuItem.Text = "すべての材質から設定ログを消去";
            this.すべての設定を消去ToolStripMenuItem.Click += new System.EventHandler(this.すべての設定を消去ToolStripMenuItem_Click);
            // 
            // すべての追加UVを消去ToolStripMenuItem
            // 
            this.すべての追加UVを消去ToolStripMenuItem.Name = "すべての追加UVを消去ToolStripMenuItem";
            this.すべての追加UVを消去ToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.すべての追加UVを消去ToolStripMenuItem.Text = "すべての頂点発光を消去";
            this.すべての追加UVを消去ToolStripMenuItem.Click += new System.EventHandler(this.すべての追加UVを消去ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(253, 6);
            this.toolStripMenuItem2.Visible = false;
            // 
            // 全ての材質で設定ログの再実行ToolStripMenuItem
            // 
            this.全ての材質で設定ログの再実行ToolStripMenuItem.Name = "全ての材質で設定ログの再実行ToolStripMenuItem";
            this.全ての材質で設定ログの再実行ToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.全ての材質で設定ログの再実行ToolStripMenuItem.Text = "全ての材質で設定ログの再実行";
            this.全ての材質で設定ログの再実行ToolStripMenuItem.Visible = false;
            // 
            // ヘルプHToolStripMenuItem
            // 
            this.ヘルプHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.変数一覧ToolStripMenuItem,
            this.関数一覧ToolStripMenuItem});
            this.ヘルプHToolStripMenuItem.Name = "ヘルプHToolStripMenuItem";
            this.ヘルプHToolStripMenuItem.Size = new System.Drawing.Size(75, 22);
            this.ヘルプHToolStripMenuItem.Text = "ヘルプ(&H)";
            // 
            // 変数一覧ToolStripMenuItem
            // 
            this.変数一覧ToolStripMenuItem.Name = "変数一覧ToolStripMenuItem";
            this.変数一覧ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.変数一覧ToolStripMenuItem.Text = "変数一覧";
            this.変数一覧ToolStripMenuItem.Click += new System.EventHandler(this.変数一覧ToolStripMenuItem_Click);
            // 
            // 関数一覧ToolStripMenuItem
            // 
            this.関数一覧ToolStripMenuItem.Name = "関数一覧ToolStripMenuItem";
            this.関数一覧ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.関数一覧ToolStripMenuItem.Text = "関数一覧";
            this.関数一覧ToolStripMenuItem.Click += new System.EventHandler(this.関数一覧ToolStripMenuItem_Click);
            // 
            // btnSetMat
            // 
            this.btnSetMat.Location = new System.Drawing.Point(348, 422);
            this.btnSetMat.Name = "btnSetMat";
            this.btnSetMat.Size = new System.Drawing.Size(128, 26);
            this.btnSetMat.TabIndex = 22;
            this.btnSetMat.Text = "材質から適用 >>";
            this.btnSetMat.UseVisualStyleBackColor = true;
            this.btnSetMat.Click += new System.EventHandler(this.btnSetMat_Click);
            // 
            // btnSetSelVtx
            // 
            this.btnSetSelVtx.Location = new System.Drawing.Point(214, 422);
            this.btnSetSelVtx.Name = "btnSetSelVtx";
            this.btnSetSelVtx.Size = new System.Drawing.Size(128, 26);
            this.btnSetSelVtx.TabIndex = 23;
            this.btnSetSelVtx.Text = "選択頂点に適用";
            this.btnSetSelVtx.UseVisualStyleBackColor = true;
            this.btnSetSelVtx.Click += new System.EventHandler(this.btnSetSelVtx_Click);
            // 
            // checkAutoLoadMaterialSetting
            // 
            this.checkAutoLoadMaterialSetting.AutoSize = true;
            this.checkAutoLoadMaterialSetting.Checked = true;
            this.checkAutoLoadMaterialSetting.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkAutoLoadMaterialSetting.Location = new System.Drawing.Point(519, 375);
            this.checkAutoLoadMaterialSetting.Name = "checkAutoLoadMaterialSetting";
            this.checkAutoLoadMaterialSetting.Size = new System.Drawing.Size(145, 16);
            this.checkAutoLoadMaterialSetting.TabIndex = 24;
            this.checkAutoLoadMaterialSetting.Text = "設定ログを自動読み込み";
            this.checkAutoLoadMaterialSetting.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(512, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 12);
            this.label1.TabIndex = 25;
            this.label1.Text = "*印の材質には設定ログがあります";
            // 
            // checkMOverride
            // 
            this.checkMOverride.AutoSize = true;
            this.checkMOverride.Checked = true;
            this.checkMOverride.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkMOverride.Location = new System.Drawing.Point(254, 353);
            this.checkMOverride.Name = "checkMOverride";
            this.checkMOverride.Size = new System.Drawing.Size(118, 16);
            this.checkMOverride.TabIndex = 19;
            this.checkMOverride.Text = "同名モーフの上書き";
            this.checkMOverride.UseVisualStyleBackColor = true;
            // 
            // listTexMode
            // 
            this.listTexMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listTexMode.FormattingEnabled = true;
            this.listTexMode.Items.AddRange(new object[] {
            "乗算",
            "無視",
            "高輝度抽出"});
            this.listTexMode.Location = new System.Drawing.Point(99, 66);
            this.listTexMode.Name = "listTexMode";
            this.listTexMode.Size = new System.Drawing.Size(89, 20);
            this.listTexMode.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "テクスチャモード:";
            // 
            // txtQ
            // 
            this.txtQ.Location = new System.Drawing.Point(296, 68);
            this.txtQ.Name = "txtQ";
            this.txtQ.Size = new System.Drawing.Size(149, 19);
            this.txtQ.TabIndex = 26;
            this.txtQ.Text = "0";
            // 
            // lblQ
            // 
            this.lblQ.AutoSize = true;
            this.lblQ.Location = new System.Drawing.Point(216, 71);
            this.lblQ.Name = "lblQ";
            this.lblQ.Size = new System.Drawing.Size(39, 12);
            this.lblQ.TabIndex = 25;
            this.lblQ.Tag = "txtQ";
            this.lblQ.Text = "変数Q:";
            this.lblQ.Click += new System.EventHandler(this.lbl_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 460);
            this.Controls.Add(this.checkMOverride);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkAutoLoadMaterialSetting);
            this.Controls.Add(this.btnSetSelVtx);
            this.Controls.Add(this.btnSetMat);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listMaterial);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnSetSelMat);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "AutoLuminousSetter";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSetSelMat;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ListBox listMaterial;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPower;
        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.Label lblG;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.Label lblR;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPhase;
        private System.Windows.Forms.Label lblPhase;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Label lblT;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtMP;
        private System.Windows.Forms.Label lblMP;
        private System.Windows.Forms.TextBox txtMB;
        private System.Windows.Forms.Label lblMB;
        private System.Windows.Forms.TextBox txtMG;
        private System.Windows.Forms.Label lblMG;
        private System.Windows.Forms.TextBox txtMR;
        private System.Windows.Forms.Label lblMR;
        private System.Windows.Forms.TextBox txtTexSub;
        private System.Windows.Forms.Label lblTexSub;
        private System.Windows.Forms.CheckBox checkEnable;
        private System.Windows.Forms.ComboBox listColorType;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtMName;
        private System.Windows.Forms.Label lblMName;
        private System.Windows.Forms.CheckBox checkMEnable;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 現在の設定を保存ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 設定をファイルから開くToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 編集EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 設定コピーToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 設定ペーストToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem 全頂点に適用ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem すべての設定を消去ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem すべての追加UVを消去ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 全ての材質で設定ログの再実行ToolStripMenuItem;
        private System.Windows.Forms.Button btnSetMat;
        private System.Windows.Forms.Button btnSetSelVtx;
        private System.Windows.Forms.CheckBox checkAutoLoadMaterialSetting;
        private System.Windows.Forms.CheckBox checkBRect;
        private System.Windows.Forms.ToolStripMenuItem ヘルプHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 変数一覧ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 関数一覧ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkMOverride;
        private System.Windows.Forms.TextBox txtPopup;
        private System.Windows.Forms.Label lblPopup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem 画面上の設定をリセットToolStripMenuItem;
        private System.Windows.Forms.ComboBox listTexMode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtQ;
        private System.Windows.Forms.Label lblQ;
    }
}