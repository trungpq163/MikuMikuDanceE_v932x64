﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpressionCalculator
{

    /// <summary>
    /// ExpCalculatorで使用する演算子および関数を定義するクラスです
    /// </summary>
    public class ECalOperators
    {

        uint maxpr = 0;

        public List<Operator> SingleOperands;
        public List<Operator> DualOperands;
        public List<Operator> Functions;

        public Dictionary<string, Operator> SingleOperandsDictionary;
        public Dictionary<string, Operator> DualOperandsDictionary;
        public Dictionary<string, Operator> FunctionsDictionary;

        public uint MaxPriority
        {
            get { return maxpr; }
        }


        Random rnd;


        public ECalOperators(StringComparer IdentStringComparer)
        {
            rnd = new Random();

            InitOperators();


            SingleOperandsDictionary = new Dictionary<string, Operator>(IdentStringComparer);

            foreach (Operator op in SingleOperands)
            {
                SingleOperandsDictionary.Add(op.OperatorScript, op);
            }


            DualOperandsDictionary = new Dictionary<string, Operator>(IdentStringComparer);

            foreach (Operator op in DualOperands)
            {
                DualOperandsDictionary.Add(op.OperatorScript, op);
            }


            FunctionsDictionary = new Dictionary<string, Operator>(IdentStringComparer);

            foreach (Operator op in Functions)
            {
                FunctionsDictionary.Add(op.OperatorScript, op);
            }

        }


        public class Operator
        {

            public Operator()
            {

            }

            public Operator(string script)
            {
                this.OperatorScript = script;
            }

            /// <summary> オペレータと紐付けられた演算子または関数名です </summary>
            public string OperatorScript = "";

            /// <summary> オペレータを演算子として使用する際の優先順位です。0が最も優先されます。 </summary>
            public uint Priority = 0;

            //実際の演算を行う関数のデリゲートです
            //ここに追加する場合はExpCalculatorの改造が必要です
            public delegate int dg_ifunc0arg();
            public delegate int dg_ifunc1arg(int x);
            public delegate int dg_ifunc2arg(int x, int y);
            public delegate int dg_ifunc3arg(int x, int y, int z);

            public delegate double dg_dfunc0arg();
            public delegate double dg_dfunc1arg(double x);
            public delegate double dg_dfunc2arg(double x, double y);
            public delegate double dg_dfunc3arg(double x, double y, double z);

            public delegate int dg_dcompfunc2arg(double x, double y);
            public delegate int dg_tchange(double x);


            /// <summary> 0引数の整数オペレータです </summary>
            public dg_ifunc0arg ifunc0arg = null;
            /// <summary> 1引数の整数オペレータです </summary>
            public dg_ifunc1arg ifunc1arg = null;
            /// <summary> 2引数の整数オペレータです </summary>
            public dg_ifunc2arg ifunc2arg = null;
            /// <summary> 3引数の整数オペレータです </summary>
            public dg_ifunc3arg ifunc3arg = null;

            /// <summary> 0引数の浮動小数演オペレータです </summary>
            public dg_dfunc0arg dfunc0arg = null;
            /// <summary> 1引数の浮動小数演オペレータです </summary>
            public dg_dfunc1arg dfunc1arg = null;
            /// <summary> 2引数の浮動小数演オペレータです </summary>
            public dg_dfunc2arg dfunc2arg = null;
            /// <summary> 3引数の浮動小数演オペレータです </summary>
            public dg_dfunc3arg dfunc3arg = null;

            /// <summary> 比較に使用されるオペレータです </summary>
            public dg_dcompfunc2arg comp = null;

            /// <summary> 型変換に使用されるオペレータです </summary>
            public dg_tchange tchange = null;

        }


        void InitOperators()
        {

            Operator ope;

            SingleOperands = new List<Operator>();
            DualOperands = new List<Operator>();



            ope = new Operator();
            ope.OperatorScript = "!";
            ope.ifunc1arg = (x) => ((x == 0) ? 1 : 0);
            ope.dfunc1arg = (x) => ((x == 0) ? 1 : 0);
            SingleOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "-";
            ope.ifunc1arg = (x) => (-x);
            ope.dfunc1arg = (x) => (-x);
            SingleOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "~";
            ope.ifunc1arg = (x) => (~x);
            SingleOperands.Add(ope);



            ope = new Operator();
            ope.OperatorScript = "*";
            ope.ifunc2arg = (x, y) => (x * y);
            ope.dfunc2arg = (x, y) => (x * y);
            ope.Priority = 2;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "/";
            ope.ifunc2arg = (x, y) => (x / y);
            ope.dfunc2arg = (x, y) => (x / y);
            ope.Priority = 2;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "%";
            ope.ifunc2arg = (x, y) => (x % y);
            ope.dfunc2arg = (x, y) => (x % y);
            ope.Priority = 2;
            DualOperands.Add(ope);


            ope = new Operator();
            ope.OperatorScript = "+";
            ope.ifunc2arg = (x, y) => (x + y);
            ope.dfunc2arg = (x, y) => (x + y);
            ope.Priority = 3;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "-";
            ope.ifunc2arg = (x, y) => (x - y);
            ope.dfunc2arg = (x, y) => (x - y);
            ope.Priority = 3;
            DualOperands.Add(ope);


            ope = new Operator();
            ope.OperatorScript = "<<";
            ope.ifunc2arg = (x, y) => (x << y);
            ope.Priority = 4;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = ">>";
            ope.ifunc2arg = (x, y) => (x >> y);
            ope.Priority = 4;
            DualOperands.Add(ope);



            ope = new Operator();
            ope.OperatorScript = "<";
            ope.comp = (x, y) => ((x < y) ? 1 : 0);
            ope.Priority = 5;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "<=";
            ope.comp = (x, y) => ((x <= y) ? 1 : 0);
            ope.Priority = 5;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = ">";
            ope.comp = (x, y) => ((x > y) ? 1 : 0);
            ope.Priority = 5;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = ">=";
            ope.comp = (x, y) => ((x >= y) ? 1 : 0);
            ope.Priority = 5;
            DualOperands.Add(ope);


            ope = new Operator();
            ope.OperatorScript = "==";
            ope.comp = (x, y) => ((x == y) ? 1 : 0);
            ope.Priority = 6;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "!=";
            ope.comp = (x, y) => ((x != y) ? 1 : 0);
            ope.Priority = 6;
            DualOperands.Add(ope);


            ope = new Operator();
            ope.OperatorScript = "&";
            ope.ifunc2arg = (x, y) => (x & y);
            ope.Priority = 7;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "And";
            ope.ifunc2arg = (x, y) => (x & y);
            ope.Priority = 7;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "^";
            ope.ifunc2arg = (x, y) => (x ^ y);
            ope.Priority = 8;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "Xor";
            ope.ifunc2arg = (x, y) => (x ^ y);
            ope.Priority = 8;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "|";
            ope.ifunc2arg = (x, y) => (x | y);
            ope.Priority = 9;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "Or";
            ope.ifunc2arg = (x, y) => (x | y);
            ope.Priority = 9;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "&&";
            ope.ifunc2arg = (x, y) => (((x != 0) && (y != 0)) ? 1 : 0);
            ope.dfunc2arg = (x, y) => (((x != 0) && (y != 0)) ? 1 : 0);
            ope.Priority = 10;
            DualOperands.Add(ope);

            ope = new Operator();
            ope.OperatorScript = "||";
            ope.ifunc2arg = (x, y) => (((x != 0) || (y != 0)) ? 1 : 0);
            ope.dfunc2arg = (x, y) => (((x != 0) || (y != 0)) ? 1 : 0);
            ope.Priority = 11;
            DualOperands.Add(ope);


            maxpr = 0;

            foreach (Operator op1 in DualOperands)
            {
                if (op1.Priority > maxpr) maxpr = op1.Priority;
            }



            Functions = new List<Operator>();

            ope = new Operator("abs");
            ope.ifunc1arg = (x) => (Math.Abs(x));
            ope.dfunc1arg = (x) => (Math.Abs(x));
            Functions.Add(ope);

            ope = new Operator("sin");
            ope.dfunc1arg = (x) => (Math.Sin(x));
            Functions.Add(ope);

            ope = new Operator("cos");
            ope.dfunc1arg = (x) => (Math.Cos(x));
            Functions.Add(ope);

            ope = new Operator("tan");
            ope.dfunc1arg = (x) => (Math.Tan(x));
            Functions.Add(ope);


            ope = new Operator("acos");
            ope.dfunc1arg = (x) => (Math.Acos(x));
            Functions.Add(ope);

            ope = new Operator("asin");
            ope.dfunc1arg = (x) => (Math.Asin(x));
            Functions.Add(ope);

            ope = new Operator("atan");
            ope.dfunc1arg = (x) => (Math.Atan(x));
            Functions.Add(ope);

            ope = new Operator("atan2");
            ope.dfunc2arg = (x, y) => (Math.Atan2(x, y));
            Functions.Add(ope);

            ope = new Operator("atan2s");
            ope.dfunc2arg = (x, y) => ((Math.Atan2(x, y) / Math.PI + 1) / 2);
            Functions.Add(ope);

            ope = new Operator("sinh");
            ope.dfunc1arg = (x) => (Math.Sinh(x));
            Functions.Add(ope);

            ope = new Operator("cosh");
            ope.dfunc1arg = (x) => (Math.Cosh(x));
            Functions.Add(ope);

            ope = new Operator("tanh");
            ope.dfunc1arg = (x) => (Math.Tanh(x));
            Functions.Add(ope);


            ope = new Operator("round");
            ope.dfunc1arg = (x) => (Math.Round(x));
            Functions.Add(ope);

            ope = new Operator("trunc");
            ope.dfunc1arg = (x) => (Math.Truncate(x));
            Functions.Add(ope);

            ope = new Operator("ceiling");
            ope.dfunc1arg = (x) => (Math.Ceiling(x));
            Functions.Add(ope);

            ope = new Operator("floor");
            ope.dfunc1arg = (x) => (Math.Floor(x));
            Functions.Add(ope);

            ope = new Operator("frac");
            ope.dfunc1arg = (x) => (x - Math.Floor(x));
            Functions.Add(ope);


            ope = new Operator("exp");
            ope.dfunc1arg = (x) => (Math.Exp(x));
            Functions.Add(ope);

            ope = new Operator("exp2");
            ope.dfunc1arg = (x) => (Math.Pow(2, x));
            Functions.Add(ope);

            ope = new Operator("ln");
            ope.dfunc1arg = (x) => (Math.Log(x));
            Functions.Add(ope);

            ope = new Operator("log");
            ope.dfunc1arg = (x) => (Math.Log10(x));
            Functions.Add(ope);

            ope = new Operator("log2");
            ope.dfunc1arg = (x) => (Math.Log(x, 2));
            Functions.Add(ope);

            ope = new Operator("logv");
            ope.dfunc2arg = (x, y) => (Math.Log(x, y));
            Functions.Add(ope);


            ope = new Operator("pow");
            ope.dfunc2arg = (x, y) => (Math.Pow(x, y));
            Functions.Add(ope);

            ope = new Operator("sign");
            ope.ifunc1arg = (x) => (Math.Sign(x));
            ope.dfunc1arg = (x) => (Math.Sign(x));
            Functions.Add(ope);

            ope = new Operator("sqrt");
            ope.dfunc1arg = (x) => (Math.Sqrt(x));
            Functions.Add(ope);


            ope = new Operator("max");
            ope.dfunc2arg = (x, y) => ((x > y) ? x : y);
            Functions.Add(ope);

            ope = new Operator("min");
            ope.dfunc2arg = (x, y) => ((x < y) ? x : y);
            Functions.Add(ope);


            ope = new Operator("rnd");
            ope.dfunc0arg = () => (rnd.NextDouble());
            Functions.Add(ope);

            ope = new Operator("pi");
            ope.dfunc0arg = () => (Math.PI);
            Functions.Add(ope);



            ope = new Operator("saturate");
            ope.dfunc1arg = (x) => ((x < 0) ? 0 : ((x > 1) ? 1 : x));
            Functions.Add(ope);

            ope = new Operator("length");
            ope.dfunc1arg = (x) => (Math.Abs(x));
            ope.dfunc2arg = (x, y) => (Math.Sqrt(x * x + y * y));
            ope.dfunc3arg = (x, y, z) => (Math.Sqrt(x * x + y * y + z * z));
            Functions.Add(ope);

            ope = new Operator("lerp");
            ope.dfunc3arg = (x, y, z) => (x + z * (y - x));
            Functions.Add(ope);



            ope = new Operator("int");
            ope.tchange = (x) => ((int)x);
            Functions.Add(ope);


        }


    }
}
