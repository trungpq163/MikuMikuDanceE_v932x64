﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoLuminousSetter
{
    public partial class frmHelp2 : Form
    {
        public frmHelp2()
        {
            InitializeComponent();

            textBox1.Select(0, 0);
        }
    }
}
