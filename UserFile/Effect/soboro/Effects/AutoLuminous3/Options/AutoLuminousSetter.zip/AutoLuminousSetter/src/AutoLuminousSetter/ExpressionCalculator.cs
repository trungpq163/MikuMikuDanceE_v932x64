﻿using System;
using System.Collections.Generic;
using System.Text;

/*

 * 文字列の数式を解釈して解を求めるクラスです
 * 任意の演算子、関数の追加が容易です
 * 
 * 不正な構文を見つけた場合エラーをスローするので、必ず呼び出し元にてエラー処理を行ってください
 * 
 * ECalOperatorsが必要です。

 */

namespace ExpressionCalculator
{

    public class ExpCalculator
    {

        const string ErrMsg_InvSyntax = "Invalid Syntax.";
        const string ErrMsg_InvOpe = "Invalid Operand.";
        const string ErrMsg_InvFunc = "Invalid Function.";
        const string ErrMsg_ArgNum = "Faild Arguments.";
        const string ErrMsg_BadParam = "Bad Parameters.";
        const string ErrMsg_DupCon = "Duplication of a constant.";

        public enum TokenType
        {
            Disable = -1,
            Unknown = 0,
            IntValue,
            FloatValue,
            String,
            Operand,
            Ident,
            Function,
            Comma,
            ParenthesisOpen,
            ParenthesisClose,
        }


        public class Token
        {

            public Token()
            {

            }

            public Token(TokenType type)
            {
                this.Type = type;
            }

            public TokenType Type = TokenType.Unknown;

            /// <summary> TokenType.IntValueのとき使用される値です </summary>
            public int iValue = 0;

            /// <summary> TokenType.FloatValueのとき使用される値です </summary>
            public double fValue = 0;

            /// <summary> TokenType.StringおよびTokenType.Identのとき使用される文字列です </summary>
            public string sValue = "";

            /// <summary> TokenType.OperandおよびTokenType.Functionのとき使用されるオペレータです </summary>
            public ECalOperators.Operator Ope;

        }


        ECalOperators Operators;
        StringComparer strcomp;

        /// <summary>
        /// 文字列の比較に使用するStringComparerを取得します
        /// </summary>
        public StringComparer Comparer
        {
            get { return strcomp; }
        }

        /// <summary>
        /// インスタンスを作成します。大文字と小文字を区別します。
        /// </summary>
        public ExpCalculator()
        {
            strcomp = StringComparer.InvariantCulture;
            Operators = new ECalOperators(strcomp);

        }

        /// <summary>
        /// 字句の比較方法を指定してインスタンスを作成します。
        /// </summary>
        public ExpCalculator(StringComparer IdentStringComparer)
        {
            strcomp = IdentStringComparer;
            Operators = new ECalOperators(strcomp);

        }

        /// <summary>
        /// 数式の文字列を解釈し、その解を返します。
        /// </summary>
        /// <param name="Expression">数式</param>
        /// <returns>解</returns>
        public double Parse(string Expression)
        {
            return Parse(Expression, null, null);
        }

        /// <summary>
        /// 数式の文字列を解釈し、その解を返します。
        /// </summary>
        /// <param name="Expression">数式</param>
        /// <param name="iConstants">整数の定数のリスト。使用しない場合、nullを指定できます。</param>
        /// <param name="dConstants">実数の定数のリスト。使用しない場合、nullを指定できます。</param>
        /// <returns>解</returns>
        public double Parse(string Expression, Dictionary<string, int> iConstants, Dictionary<string, double> dConstants)
        {

            List<Token> Tokens;

            Tokens = LexicalAnalyzer(Expression);

            return Parse(Tokens, iConstants, dConstants);
        }

        /// <summary>
        /// 中間コードを解釈し、その解を返します。
        /// </summary>
        /// <param name="Tokens">中間コード</param>
        /// <param name="iConstants">整数の定数のリスト。使用しない場合、nullを指定できます。</param>
        /// <param name="dConstants">実数の定数のリスト。使用しない場合、nullを指定できます。</param>
        /// <returns>解</returns>
        public double Parse(List<Token> Tokens, Dictionary<string, int> iConstants, Dictionary<string, double> dConstants)
        {
            SetOperators(Tokens);

            if (iConstants == null) iConstants = new Dictionary<string, int>();
            if (dConstants == null) dConstants = new Dictionary<string, double>();

            foreach (Token tok in Tokens)
            {
                if (tok.Type == TokenType.Ident)
                {
                    bool ice = iConstants.ContainsKey(tok.sValue);
                    bool dce = dConstants.ContainsKey(tok.sValue);

                    if (ice && dce)
                    {
                        throw new System.Exception(ErrMsg_DupCon);
                    }
                    else if (ice)
                    {
                        tok.iValue = iConstants[tok.sValue];
                        tok.Type = TokenType.IntValue;
                    }
                    else if (dce)
                    {
                        tok.fValue = dConstants[tok.sValue];
                        tok.Type = TokenType.FloatValue;
                    }
                }
            }

            Token token = FullCalculation(Tokens);

            if (token.Type == TokenType.IntValue) return token.iValue;
            if (token.Type == TokenType.FloatValue) return token.fValue;

            return 0;
        }

        /// <summary>
        /// 字句解析を行い中間コード生成します。
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public List<Token> LexicalAnalyzer(string Expression)
        {
            List<Token> mTokens = new List<Token>();
            StringBuilder sb1 = new StringBuilder();

            TokenType CurrentTokenType = TokenType.Unknown;


            //番兵
            mTokens.Add(new Token(TokenType.Disable));
            Expression = Expression + " ";

            int i;
            bool isenum = false;

            for (i = 0; i < Expression.Length; i++)
            {
                char c = Expression[i];
                TokenType NextTokenType = CurrentTokenType;
                bool SplitToken = false;

                if (CurrentTokenType == TokenType.String)
                {
                    if (c == '"')
                    {
                        NextTokenType = TokenType.Unknown;
                    }
                }
                else
                {

                    if (c == 'e' || c == 'E')
                    {
                        if (CurrentTokenType == TokenType.FloatValue)
                        {
                            isenum = true;
                        }
                    }
                    else if (c == '-' || c == '+')
                    {
                        //nop
                    }
                    else
                    {
                        isenum = false;
                    }



                    if (('0' <= c && c <= '9') || isenum)
                    {
                        if (CurrentTokenType != TokenType.Ident)
                        {
                            NextTokenType = TokenType.FloatValue;
                        }
                    }
                    else if (c == '.')
                    {
                        if (CurrentTokenType != TokenType.Ident)
                        {
                            NextTokenType = TokenType.FloatValue;
                        }
                    }
                    else if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || (c == '_'))
                    {
                        NextTokenType = TokenType.Ident;
                    }
                    else if (c == ' ' || c == '\t' || c == '\r' || c == '\n')
                    {

                        NextTokenType = TokenType.Disable;

                    }
                    else if (c == '(')
                    {
                        NextTokenType = TokenType.ParenthesisOpen;
                        SplitToken = true;
                    }
                    else if (c == ',')
                    {
                        NextTokenType = TokenType.Comma;
                        SplitToken = true;
                    }
                    else if (c == ')')
                    {
                        NextTokenType = TokenType.ParenthesisClose;
                        SplitToken = true;
                    }
                    else if (c == '"')
                    {
                        NextTokenType = TokenType.String;
                    }
                    else
                    {
                        NextTokenType = TokenType.Operand;

                    }
                }

                //トークンの区切り
                if (CurrentTokenType != NextTokenType || SplitToken)
                {


                    if (CurrentTokenType == TokenType.FloatValue)
                    {
                        string str = sb1.ToString();
                        Token token = new Token();

                        if (str.IndexOf('.') < 0 && str.IndexOf('e') < 0 && str.IndexOf('E') < 0)
                        {
                            token.Type = TokenType.IntValue;
                            token.iValue = int.Parse(str);
                        }
                        else
                        {
                            token.Type = TokenType.FloatValue;
                            token.fValue = double.Parse(str);
                        }

                        mTokens.Add(token);

                    }
                    else if (CurrentTokenType == TokenType.String)
                    {
                        string str = sb1.ToString();
                        str = str.Substring(1, str.Length - 2);
                        Token token = new Token(CurrentTokenType);
                        token.sValue = str;
                        mTokens.Add(token);
                    }
                    else if (CurrentTokenType == TokenType.Ident)
                    {
                        string str = sb1.ToString();
                        Token token = new Token(CurrentTokenType);
                        token.sValue = str;
                        mTokens.Add(token);
                    }
                    else if (CurrentTokenType == TokenType.Operand)
                    {

                        string str = sb1.ToString();

                        //単項演算子の分離
                        if (!Operators.DualOperandsDictionary.ContainsKey(str))
                        {
                            foreach (ECalOperators.Operator op in Operators.SingleOperands)
                            {
                                if (str.Length > op.OperatorScript.Length)
                                {
                                    if (strcomp.Compare(str.Substring(str.Length - op.OperatorScript.Length), op.OperatorScript) == 0)
                                    {
                                        Token token2 = new Token(CurrentTokenType);
                                        token2.sValue = str.Substring(0, str.Length - op.OperatorScript.Length);
                                        mTokens.Add(token2);

                                        str = op.OperatorScript;
                                        break;
                                    }
                                }
                            }
                        }

                        Token token = new Token(CurrentTokenType);
                        token.sValue = str;
                        mTokens.Add(token);

                    }
                    else if (CurrentTokenType == TokenType.ParenthesisOpen)
                    {
                        if (mTokens[mTokens.Count - 1].Type == TokenType.Ident)
                        {
                            mTokens[mTokens.Count - 1].Type = TokenType.Function;
                        }

                        mTokens.Add(new Token(TokenType.ParenthesisOpen));

                    }
                    else if (CurrentTokenType == TokenType.ParenthesisClose)
                    {
                        mTokens.Add(new Token(TokenType.ParenthesisClose));

                    }
                    else if (CurrentTokenType == TokenType.Comma)
                    {
                        mTokens.Add(new Token(TokenType.Comma));

                    }
                    else if (CurrentTokenType == TokenType.Disable)
                    {
                        mTokens.Add(new Token(TokenType.Disable));

                    }


                    sb1.Clear();

                    CurrentTokenType = NextTokenType;
                }

                sb1.Append(c);

            }




            for (i = mTokens.Count - 1; i >= 0; i--)
            {
                if (mTokens[i].Type == TokenType.Disable)
                {
                    mTokens.RemoveAt(i);
                }
            }


            return mTokens;
        }


        /// <summary>
        /// オペレータ設定
        /// </summary>
        /// <param name="Tokens"></param>
        void SetOperators(List<Token> Tokens)
        {
            int i;


            for (i = 0; i < Tokens.Count; i++)
            {
                Token token = Tokens[i];

                //英字オペランドの置換
                if (token.Type == TokenType.Ident)
                {

                    if (Operators.SingleOperandsDictionary.ContainsKey(token.sValue))
                    {
                        token.Type = TokenType.Operand;
                    }
                    if (Operators.DualOperandsDictionary.ContainsKey(token.sValue))
                    {
                        token.Type = TokenType.Operand;
                    }
                }


            }


            //
            for (i = 0; i < Tokens.Count; i++)
            {
                Token token = Tokens[i];

                if (token.Type == TokenType.Operand)
                {
                    bool IsSingle = false;

                    if (i == (Tokens.Count - 1))
                    {
                        throw new System.Exception(ErrMsg_InvSyntax);
                    }

                    if (i == 0)
                    {
                        IsSingle = true;
                    }
                    else
                    {
                        Token lasttoken = Tokens[i - 1];
                        Token nexttoken = Tokens[i + 1];

                        if (IsValue(nexttoken.Type) || nexttoken.Type == TokenType.ParenthesisOpen
                            || Operators.SingleOperandsDictionary.ContainsKey(nexttoken.sValue))
                        {
                            if (IsValue(lasttoken.Type) || lasttoken.Type == TokenType.ParenthesisClose)
                            {
                                IsSingle = false;
                            }
                            else
                            {
                                IsSingle = true;
                            }
                        }
                        else
                        {
                            throw new System.Exception(ErrMsg_InvSyntax);
                        }
                    }


                    if (IsSingle)
                    {
                        if (Operators.SingleOperandsDictionary.ContainsKey(token.sValue))
                        {
                            token.Ope = Operators.SingleOperandsDictionary[token.sValue];
                            //token.sValue = "";
                        }
                        else
                        {
                            throw new System.Exception(ErrMsg_InvOpe);
                        }
                    }
                    else
                    {
                        if (Operators.DualOperandsDictionary.ContainsKey(token.sValue))
                        {
                            token.Ope = Operators.DualOperandsDictionary[token.sValue];
                            //token.sValue = "";
                        }
                        else
                        {
                            throw new System.Exception(ErrMsg_InvOpe);
                        }
                    }

                }
                else if (token.Type == TokenType.Function)
                {
                    if (Operators.FunctionsDictionary.ContainsKey(token.sValue))
                    {
                        token.Ope = Operators.FunctionsDictionary[token.sValue];
                        //token.sValue = "";
                    }
                    else
                    {
                        throw new System.Exception(ErrMsg_InvOpe);
                    }
                }


            }

        }


        bool IsValue(TokenType type)
        {
            return type == TokenType.FloatValue
                || type == TokenType.IntValue
                || type == TokenType.Function
                || type == TokenType.Ident
                || type == TokenType.String

            ;
        }


        /// <summary>
        /// 式を計算します
        /// </summary>
        Token FullCalculation(List<Token> Tokens)
        {
            List<Token> mTokens = new List<Token>();

            foreach (Token token in Tokens) mTokens.Add(token); //リストの複製

            int i, j, k;

            for (k = 0; k < 1000; k++)
            {

                bool ParenthesisFound = false;
                int lastOpen = -1;

                for (i = 0; i < mTokens.Count; i++)
                {
                    Token token = mTokens[i];

                    if (token.Type == TokenType.ParenthesisOpen)
                    {
                        lastOpen = i;
                        ParenthesisFound = true;
                    }
                    else if (token.Type == TokenType.ParenthesisClose)
                    {
                        if (lastOpen < 0) throw new System.Exception(ErrMsg_InvSyntax);

                        List<Token> pTokens = mTokens.GetRange(lastOpen + 1, i - lastOpen - 1);
                        List<Token> rTokens = SplitCalculation(pTokens);

                        bool IsFunction = false;

                        if (lastOpen > 0)
                        {
                            if (mTokens[lastOpen - 1].Type == TokenType.Function)
                            {
                                ECalOperators.Operator op = mTokens[lastOpen - 1].Ope;
                                Token rToken = null;
                                const int maxargnum = 8;

                                bool[] isint = new bool[maxargnum];
                                bool[] isval = new bool[maxargnum];
                                int[] ival = new int[maxargnum];
                                double[] dval = new double[maxargnum];
                                bool allint = true;

                                for (j = 0; j < rTokens.Count; j++)
                                {
                                    if (j >= maxargnum) break;

                                    if (rTokens[j].Type == TokenType.IntValue)
                                    {
                                        isint[j] = true;
                                        isval[j] = true;
                                        ival[j] = rTokens[j].iValue;
                                        dval[j] = rTokens[j].iValue;
                                    }
                                    else if (rTokens[j].Type == TokenType.FloatValue)
                                    {
                                        allint = false;
                                        isval[j] = true;
                                        dval[j] = rTokens[j].fValue;
                                    }
                                }


                                if (op.ifunc3arg != null && allint && rTokens.Count == 3)
                                {
                                    int val = op.ifunc3arg(ival[0], ival[1], ival[2]);
                                    rToken = new Token(TokenType.IntValue);
                                    rToken.iValue = val;
                                }
                                else if (op.ifunc2arg != null && allint && rTokens.Count == 2)
                                {
                                    int val = op.ifunc2arg(ival[0], ival[1]);
                                    rToken = new Token(TokenType.IntValue);
                                    rToken.iValue = val;
                                }
                                else if (op.ifunc1arg != null && allint && rTokens.Count == 1)
                                {
                                    int val = op.ifunc1arg(ival[0]);
                                    rToken = new Token(TokenType.IntValue);
                                    rToken.iValue = val;
                                }
                                else if (op.ifunc0arg != null && rTokens.Count == 0)
                                {
                                    int val = op.ifunc0arg();
                                    rToken = new Token(TokenType.IntValue);
                                    rToken.iValue = val;
                                }

                                else if (op.dfunc3arg != null && rTokens.Count == 3)
                                {
                                    double val = op.dfunc3arg(dval[0], dval[1], dval[2]);
                                    rToken = new Token(TokenType.FloatValue);
                                    rToken.fValue = val;
                                }
                                else if (op.dfunc2arg != null && rTokens.Count == 2)
                                {
                                    double val = op.dfunc2arg(dval[0], dval[1]);
                                    rToken = new Token(TokenType.FloatValue);
                                    rToken.fValue = val;
                                }
                                else if (op.dfunc1arg != null && rTokens.Count == 1)
                                {
                                    double val = op.dfunc1arg(dval[0]);
                                    rToken = new Token(TokenType.FloatValue);
                                    rToken.fValue = val;
                                }
                                else if (op.tchange != null && rTokens.Count == 1)
                                {
                                    int val = op.tchange(dval[0]);
                                    rToken = new Token(TokenType.IntValue);
                                    rToken.iValue = val;
                                }
                                else if (op.dfunc0arg != null && rTokens.Count == 0)
                                {
                                    double val = op.dfunc0arg();
                                    rToken = new Token(TokenType.FloatValue);
                                    rToken.fValue = val;
                                }

                                if (rToken == null) throw new System.Exception(ErrMsg_ArgNum);

                                mTokens.RemoveRange(lastOpen - 1, i - lastOpen + 2);
                                mTokens.Insert(lastOpen - 1, rToken);

                                IsFunction = true;

                            }
                        }

                        if (IsFunction == false)
                        {
                            mTokens.RemoveRange(lastOpen, i - lastOpen + 1);
                            mTokens.Insert(lastOpen, rTokens[0]);
                        }

                        ParenthesisFound = true;
                        lastOpen = -1;

                        break;
                    }
                }

                if (lastOpen >= 0)
                {
                    throw new System.Exception(ErrMsg_InvSyntax);
                }

                if (ParenthesisFound == false) break;

            }


            return SimpleCalculation(mTokens);
        }

        /// <summary>
        /// カンマで区切られた複数の、括弧を含まない数値と演算子のみの式を計算します
        /// </summary>
        List<Token> SplitCalculation(List<Token> Tokens)
        {
            List<Token> mTokens = new List<Token>();

            if (Tokens.Count == 0) return mTokens;

            int i, start = 0;

            for (i = 0; i < Tokens.Count; i++)
            {
                if (Tokens[i].Type == TokenType.Comma)
                {
                    mTokens.Add(SimpleCalculation(Tokens.GetRange(start, i - start)));
                    start = i + 1;
                }
            }

            mTokens.Add(SimpleCalculation(Tokens.GetRange(start, Tokens.Count - start)));

            return mTokens;
        }

        /// <summary>
        /// 単独の、括弧を含まない数値と演算子のみの式を計算します
        /// </summary>
        Token SimpleCalculation(List<Token> Tokens)
        {
            List<Token> mTokens = new List<Token>();

            if (Tokens.Count == 0) throw new System.Exception(ErrMsg_InvSyntax);

            foreach (Token token in Tokens) mTokens.Add(token); //リストの複製

            int i, j, k;

            for (i = 0; i <= Operators.MaxPriority; i++)
            {

                for (k = 0; k < 1000; k++)
                {

                    bool OpeFound = false;


                    for (j = 0; j < mTokens.Count; j++)
                    {
                        Token token = mTokens[j];

                        if (token.Type == TokenType.Operand)
                        {
                            ECalOperators.Operator op = token.Ope;

                            if (op.Priority == i)
                            {

                                Token lasttoken = null, nexttoken = null;

                                bool OpeSuccess = false;

                                if (j > 0) lasttoken = mTokens[j - 1];
                                if (j < mTokens.Count - 1) nexttoken = mTokens[j + 1];

                                bool last_isint = false, next_isint = false;
                                bool last_isval = false, next_isval = false;

                                int last_ival = 0, next_ival = 0;
                                double last_dval = 0, next_dval = 0;

                                if (lasttoken != null)
                                {
                                    if (lasttoken.Type == TokenType.IntValue)
                                    {
                                        last_isint = true;
                                        last_isval = true;
                                        last_ival = lasttoken.iValue;
                                        last_dval = (double)lasttoken.iValue;
                                    }
                                    else if (lasttoken.Type == TokenType.FloatValue)
                                    {
                                        last_isval = true;
                                        last_dval = lasttoken.fValue;
                                    }
                                }


                                if (nexttoken != null)
                                {
                                    if (nexttoken.Type == TokenType.IntValue)
                                    {
                                        next_isint = true;
                                        next_isval = true;
                                        next_ival = nexttoken.iValue;
                                        next_dval = (double)nexttoken.iValue;
                                    }
                                    else if (nexttoken.Type == TokenType.FloatValue)
                                    {
                                        next_isval = true;
                                        next_dval = nexttoken.fValue;
                                    }
                                }



                                if (op.ifunc1arg != null)
                                {
                                    if (next_isint)
                                    {
                                        int val = token.Ope.ifunc1arg(next_ival);
                                        Token newtoken = new Token(TokenType.IntValue);
                                        newtoken.iValue = val;

                                        mTokens.RemoveAt(j + 1);
                                        mTokens.RemoveAt(j);
                                        mTokens.Insert(j, newtoken);

                                        OpeSuccess = true;
                                    }
                                }
                                if (op.dfunc1arg != null && !OpeSuccess)
                                {
                                    if (next_isval)
                                    {
                                        double val = token.Ope.dfunc1arg(next_dval);
                                        Token newtoken = new Token(TokenType.FloatValue);
                                        newtoken.fValue = val;

                                        mTokens.RemoveAt(j + 1);
                                        mTokens.RemoveAt(j);
                                        mTokens.Insert(j, newtoken);

                                        OpeSuccess = true;
                                    }
                                }
                                if (op.ifunc2arg != null && !OpeSuccess)
                                {
                                    if (last_isint && next_isint)
                                    {
                                        int val = token.Ope.ifunc2arg(last_ival, next_ival);
                                        Token newtoken = new Token(TokenType.IntValue);
                                        newtoken.iValue = val;

                                        mTokens.RemoveAt(j + 1);
                                        mTokens.RemoveAt(j);
                                        mTokens.RemoveAt(j - 1);
                                        mTokens.Insert(j - 1, newtoken);

                                        OpeSuccess = true;
                                    }
                                }
                                if (op.dfunc2arg != null && !OpeSuccess)
                                {
                                    if (last_isval && next_isval)
                                    {
                                        double val = token.Ope.dfunc2arg(last_dval, next_dval);
                                        Token newtoken = new Token(TokenType.FloatValue);
                                        newtoken.fValue = val;

                                        mTokens.RemoveAt(j + 1);
                                        mTokens.RemoveAt(j);
                                        mTokens.RemoveAt(j - 1);
                                        mTokens.Insert(j - 1, newtoken);

                                        OpeSuccess = true;
                                    }
                                }
                                if (op.comp != null && !OpeSuccess)
                                {
                                    if (last_isval && next_isval)
                                    {
                                        int val = token.Ope.comp(last_dval, next_dval);
                                        Token newtoken = new Token(TokenType.IntValue);
                                        newtoken.iValue = val;

                                        mTokens.RemoveAt(j + 1);
                                        mTokens.RemoveAt(j);
                                        mTokens.RemoveAt(j - 1);
                                        mTokens.Insert(j - 1, newtoken);

                                        OpeSuccess = true;
                                    }
                                }

                                if (OpeSuccess == false)
                                {
                                    throw new System.Exception(ErrMsg_InvSyntax);
                                }


                                OpeFound = true;
                                break;

                            }
                        }
                    }

                    if (OpeFound == false) break;
                }

                if (mTokens.Count == 1) break;
            }

            if (mTokens.Count != 1)
            {
                throw new System.Exception(ErrMsg_InvSyntax);
            }

            if (mTokens[0].Type != TokenType.IntValue && mTokens[0].Type != TokenType.FloatValue)
            {
                throw new System.Exception(ErrMsg_InvSyntax);
            }

            return mTokens[0];
        }









    }
}
